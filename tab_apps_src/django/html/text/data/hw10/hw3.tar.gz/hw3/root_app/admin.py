from django.contrib import admin
from .models import Book, BookDetails

# Register your models here.
admin.site.register(Book)
admin.site.register(BookDetails)

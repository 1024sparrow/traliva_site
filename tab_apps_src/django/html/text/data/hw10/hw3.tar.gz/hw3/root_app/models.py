from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Book(models.Model):
    author = models.CharField(max_length=200)
    title = models.CharField(max_length=200)
    def __str__(self):
        return '[' + self.author + '] ' + self.title

class BookDetails(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    price = models.IntegerField(default = 0)

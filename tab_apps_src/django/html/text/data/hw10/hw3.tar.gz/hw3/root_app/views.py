from django.shortcuts import render
from django.http import HttpResponse, Http404
from .models import Book, BookDetails

# Create your views here.
def index(request):
    book_list = Book.objects.all();
    context = {'book_list':book_list}
    return render(request, 'root_app/catalogue.html', context)
def details(request, book_id):
    try:
        bookDetails = BookDetails.objects.get(book=book_id)
    except BookDetails.DoesNotExist:
        raise Http404('Details for this book does not exist')
    return HttpResponse('You see details for book#' + book_id + '<br/>Price: %d rubley' %(bookDetails.price))
